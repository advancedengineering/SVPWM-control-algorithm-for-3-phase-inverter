//###########################################################################
//
// FILE:   Example_2833xEPwmUpDownAQ.c
//
// TITLE:  ePWM Action Qualifier Module using up/down count Example
//
//! \addtogroup f2833x_example_list
//! <h1>ePWM Action Qualifier Module using up/down count (epwm_updown_aq)</h1>
//!
//! This example configures ePWM1, ePWM2, ePWM3 to produce an waveform with
//! independent modulation on EPWMxA and EPWMxB. The compare values CMPA
//! and CMPB are modified within the ePWM's ISR. The TB counter is in up/down
//! count mode for this example.
//!
//! Monitor ePWM1-ePWM3 pins on an oscilloscope as described
//!
//! \b External \b Connections \n
//!  - EPWM1A is on GPIO0
//!  - EPWM1B is on GPIO1
//!  - EPWM2A is on GPIO2
//!  - EPWM2B is on GPIO3
//!  - EPWM3A is on GPIO4
//!  - EPWM3B is on GPIO5
//
//###########################################################################
// $TI Release: F2833x Support Library v2.02.00.00 $
// $Release Date: Fri Feb 12 19:15:21 IST 2021 $
// $Copyright:
// Copyright (C) 2009-2021 Texas Instruments Incorporated - http://www.ti.com/
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
// 
//   Redistributions of source code must retain the above copyright 
//   notice, this list of conditions and the following disclaimer.
// 
//   Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the 
//   documentation and/or other materials provided with the   
//   distribution.
// 
//   Neither the name of Texas Instruments Incorporated nor the names of
//   its contributors may be used to endorse or promote products derived
//   from this software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// $
//###########################################################################
//tgc
#include "math.h"

typedef struct
{
   float Ualpha;
   float Ubeta;
   float ang;
   float Vdc;
   float T;
}reference;
reference reference_init={0,0,0,500,1};//
reference *vv=&reference_init;
int i=0;
void reference_vec(reference *v);
void svmgen(reference *v);
#define PRD_L  7500                // PWM���ڼĴ���
#define PI 3.1415926
#define Ts 1e-4
#define PI2 1.57079632675
float tmr1,tmr2,tmr3;

//#define PI  3.1415926535
//#define PI2 1.57079632675   // PI/2
//#define Ts 1e-4  // Ts is different from T!
//#define InterruptTime Ts*1e6
//typedef struct  { float  Ualpha;  // Input: reference alpha-axis phase voltage
//                  float  Ubeta;   // Input: reference beta-axis phase voltage
//                  float  Vdc;     // Input: DC voltage
//                  float  T;       // Input: PWM Modulation Period
//                  float  Tcmpa; // Output: reference phase-a switching function
//                  float  Tcmpb; // Output: reference phase-b switching function
//                  float  Tcmpc; // Output: reference phase-c switching function
//                  void (*calc)();       // Pointer to calculation function
//                } SVPWM_2L;
//SVPWM_2L  SVPWM;
//void svpwm_2L_calc(SVPWM_2L *p);
//void parameters_init()
//{
//    SVPWM.T = 1; //i have per-unit the T.
//    SVPWM.Tcmpa = 0.5;
//    SVPWM.Tcmpb = 0.5;
//    SVPWM.Tcmpc = 0.5;
//    SVPWM.Ualpha = 0;
//    SVPWM.Ubeta = 0;
//    SVPWM.Vdc = 311;
//    SVPWM.calc = svpwm_2L_calc;
//}


//
// Included Files
//
#include "DSP28x_Project.h"     // Device Headerfile and Examples Include File

//
// Typedefs
//
//typedef struct
//{
//    volatile struct EPWM_REGS *EPwmRegHandle;
//    Uint16 EPwm_CMPA_Direction;
//    Uint16 EPwm_CMPB_Direction;
//    Uint16 EPwmTimerIntCount;
//    Uint16 EPwmMaxCMPA;
//    Uint16 EPwmMinCMPA;
//    Uint16 EPwmMaxCMPB;
//    Uint16 EPwmMinCMPB;
//} EPWM_INFO;

//
// Function Prototypes
//
void InitEPwm1Example(void);
void InitEPwm2Example(void);
void InitEPwm3Example(void);
__interrupt void epwm1_isr(void);
//__interrupt void epwm2_isr(void);
//__interrupt void epwm3_isr(void);
//void update_compare(EPWM_INFO*);

//
// Globals 
//
//EPWM_INFO epwm1_info;
//EPWM_INFO epwm2_info;
//EPWM_INFO epwm3_info;

//
// Defines that configure the period for each timer
//
//#define EPWM1_TIMER_TBPRD  2000  // Period register
//#define EPWM1_MAX_CMPA     1950
//#define EPWM1_MIN_CMPA       50
//#define EPWM1_MAX_CMPB     1950
//#define EPWM1_MIN_CMPB       50
//
//#define EPWM2_TIMER_TBPRD  2000  // Period register
//#define EPWM2_MAX_CMPA     1950
//#define EPWM2_MIN_CMPA       50
//#define EPWM2_MAX_CMPB     1950
//#define EPWM2_MIN_CMPB       50
//
//#define EPWM3_TIMER_TBPRD  2000  // Period register
//#define EPWM3_MAX_CMPA      950
//#define EPWM3_MIN_CMPA       50
//#define EPWM3_MAX_CMPB     1950
//#define EPWM3_MIN_CMPB     1050

//
// Defines to keep track of which way the compare value is moving
//
//#define EPWM_CMP_UP   1
//#define EPWM_CMP_DOWN 0

//
// Main
//
void main(void)
{
    //
    // Step 1. Initialize System Control:
    // PLL, WatchDog, enable Peripheral Clocks
    // This example function is found in the DSP2833x_SysCtrl.c file.
    //
    InitSysCtrl();

    //
    // Step 2. Initialize GPIO:
    // This example function is found in the DSP2833x_Gpio.c file and
    // illustrates how to set the GPIO to it's default state.
    //
    // InitGpio();  // Skipped for this example

    //
    // For this case just init GPIO pins for ePWM1, ePWM2, ePWM3
    // These functions are in the DSP2833x_EPwm.c file
    //
    InitEPwm1Gpio();
    InitEPwm2Gpio();
    InitEPwm3Gpio();

    //
    // Step 3. Clear all interrupts and initialize PIE vector table:
    // Disable CPU interrupts
    //
    DINT;

    //
    // Initialize the PIE control registers to their default state.
    // The default state is all PIE interrupts disabled and flags
    // are cleared.
    // This function is found in the DSP2833x_PieCtrl.c file.
    //
    InitPieCtrl();

    //
    // Disable CPU interrupts and clear all CPU interrupt flags
    //
    IER = 0x0000;
    IFR = 0x0000;

    //
    // Initialize the PIE vector table with pointers to the shell Interrupt
    // Service Routines (ISR).
    // This will populate the entire table, even if the interrupt
    // is not used in this example.  This is useful for debug purposes.
    // The shell ISR routines are found in DSP2833x_DefaultIsr.c.
    // This function is found in DSP2833x_PieVect.c.
    //
    InitPieVectTable();

    //
    // Interrupts that are used in this example are re-mapped to
    // ISR functions found within this file.
    //
    EALLOW;         // This is needed to write to EALLOW protected registers
    PieVectTable.EPWM1_INT = &epwm1_isr;
//    PieVectTable.EPWM2_INT = &epwm2_isr;
//    PieVectTable.EPWM3_INT = &epwm3_isr;
    EDIS;    // This is needed to disable write to EALLOW protected registers

    //
    // Step 4. Initialize all the Device Peripherals:
    // This function is found in DSP2833x_InitPeripherals.c
    //
    // InitPeripherals();  // Not required for this example
    //
    // For this example, only initialize the ePWM
    //
    EALLOW;
    SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;
    EDIS;

    InitEPwm1Example();
    InitEPwm2Example();
    InitEPwm3Example();

    EALLOW;
    SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;

    //
    // Step 5. User specific code, enable interrupts
    //

    //
    // Enable CPU INT3 which is connected to EPWM1-3 INT
    //
    IER |= M_INT3;

    //
    // Enable EPWM INTn in the PIE: Group 3 interrupt 1-3
    //
    PieCtrlRegs.PIEIER3.bit.INTx1 = 1;
//    PieCtrlRegs.PIEIER3.bit.INTx2 = 1;
//    PieCtrlRegs.PIEIER3.bit.INTx3 = 1;

    //
    // Enable global Interrupts and higher priority real-time debug events
    //
    EINT;   // Enable Global interrupt INTM
    ERTM;   // Enable Global realtime interrupt DBGM

    //
    // Step 6. IDLE loop. Just sit and loop forever (optional)
    //
    for(;;)
    {
        __asm("          NOP");
    }
}

//
// epwm1_isr - 
//
__interrupt void 
epwm1_isr(void)
{
    //
    // Update the CMPA and CMPB values
    //
       svmgen(vv);
       EPwm1Regs.CMPA.half.CMPA=tmr1;
       EPwm2Regs.CMPA.half.CMPA=tmr2;
       EPwm3Regs.CMPA.half.CMPA=tmr3;
//       EPwm1Regs.CMPB=tmr1;
//       EPwm2Regs.CMPB=tmr2;
//       EPwm3Regs.CMPB=tmr3;
//    static int i=0;

//       SVPWM.Ualpha = 100 * sin(100 * PI * SVPWM.T * Ts * i);
//       SVPWM.Ubeta = 100 * sin(100 * PI * SVPWM.T * Ts * i + PI2);
//
//       SVPWM.calc(&SVPWM);

//       EPwm1Regs.CMPA.half.CMPA = SVPWM.Tcmpa;
//       EPwm2Regs.CMPA.half.CMPA = SVPWM.Tcmpb;
//       EPwm3Regs.CMPA.half.CMPA = SVPWM.Tcmpc;
//       i++;
//       if (i >= 200) i=0;
    //
    // Clear INT flag for this timer ���жϱ�־
    //
    EPwm1Regs.ETCLR.bit.INT = 1;

    //
    // Acknowledge this interrupt to receive more interrupts from group 3 ���ж���Ӧ
    //
    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
}

//tgc
// epwm2_isr -
//
//__interrupt void
//epwm2_isr(void)
//{
//    //
//    // Update the CMPA and CMPB values
//    //
//    update_compare(&epwm2_info);
//
//    //
//    // Clear INT flag for this timer
//    //
//    EPwm2Regs.ETCLR.bit.INT = 1;
//
//    //
//    // Acknowledge this interrupt to receive more interrupts from group 3
//    //
//    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
//}
//
////
//// epwm3_isr -
////
//__interrupt void
//epwm3_isr(void)
//{
//    //
//    // Update the CMPA and CMPB values
//    //
//    update_compare(&epwm3_info);
//
//    //
//    // Clear INT flag for this timer
//    //
//    EPwm3Regs.ETCLR.bit.INT = 1;
//
//    //
//    // Acknowledge this interrupt to receive more interrupts from group 3
//    //
//    PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;
//}

//tgc
void reference_vec(reference *v)
{
//  float  ang;
//  ang=(v->ang/360)*2*PI;                    //�Ƕ�ת��Ϊ����
//  static int i=0;
  v->Ualpha=231*sin(100 * PI * v->T * Ts * i);
  v->Ubeta=231*sin(100 * PI * v->T * Ts * i + PI2);
  i++;
  if (i >= 200) i=0;
}

void svmgen(reference *v)
{
   float Va,Vb,Vc,t1,t2,Ta,Tb,Tc,X,Y,Z,K=1.73205081,temp,taon,tbon,tcon;
   Uint32 sector=0;                                               // sector=a+2b+4c ����״̬��ʾ ע�⣺setor��ֵ1~6����������˳���Ӧ
   reference_vec(v);
   Va=v->Ubeta;                                                      // Va = Uq
   Vb=(-0.5) * v->Ubeta + (0.8660254) * v->Ualpha;                       // Vb = 1/2*(sqrt(3)*Ud - Uq)         sqrt(3)/2=0.866
   Vc=(-0.5) * v->Ubeta - (0.8660254) * v->Ualpha;                       // Vc = -1/2*(sqrt(3)Ud + Uq)
   if(Va>0.0000001)                                               // �ж������ĸ�����
   sector=1;                                                      // Va>0 �� a=1������a=0
   if(Vb>0.0000001)                                               //
   sector=sector+2;                                               // Vb>0 �� b=1������b=0
   if(Vc>0.0000001)                                               //
   sector=sector+4;                                               // Vc>0 �� c=1; ����c=0

   X= K*v->Ubeta/v->Vdc*v->T;
   Y=(K*v->Ubeta+3*v->Ualpha)/(2*v->Vdc)*v->T;
   Z=(K*v->Ubeta-3*v->Ualpha)/(2*v->Vdc)*v->T;

   switch(sector){
     case 1:                               //sector==1 ��Ӧ����II
       t1=Z;
       t2=Y;
           break;
     case 2:                               //sector==2 ��Ӧ����VI
       t1=Y;
       t2=-X;

       break;
     case 3:                               //sector==3 ��Ӧ����I
       t1=-Z;
       t2=X;
       break;
     case 4:                               //sector==4 ��Ӧ����IV
       t1=-X;
       t2=Z;
       break;
     case 5:                               //sector==5 ��Ӧ����III
       t1=X;
       t2=-Y;
       break;
     case 6:                              //sector==6 ��Ӧ����V
       t1=-Y;
       t2=-Z;
       break;
     default:{;}

   }
   if((t1+t2)>v->T)//�Թ�����������е���
        {
             temp=t1+t2;
             t1=t1*v->T/temp;
             t2=t2*v->T/temp;
        }
   taon=(0.25)*(1-t1-t2);
   tbon=taon+t1/2;
   tcon=tbon+t2/2;
   switch(sector)
        {
          case 1:
          Ta=tbon;
          Tb=taon;
          Tc=tcon;
          break;
          case 2:
          Ta=taon;
          Tb=tcon;
          Tc=tbon;
          break;
          case 3:
              Ta=taon;
              Tb=tbon;
              Tc=tcon;
          break;
          case 4:
              Ta=tcon;
              Tb=tbon;
              Tc=taon;
          break;
          case 5:
              Ta=tcon;
              Tb=taon;
              Tc=tbon;
          break;
          case 6:
              Ta=tbon;
              Tb=tcon;
              Tc=taon;
          break;
          default:                             //sector=0��sector=7ʱ����
                 Ta=0.5;
                 Tb=0.5;
                 Tc=0.5;
        }
   tmr1=(int)(Ta*PRD_L*2);
   tmr2=(int)(Tb*PRD_L*2);
   tmr3=(int)(Tc*PRD_L*2);
}

//tgc
//void svpwm_2L_calc(SVPWM_2L *p)
//{
//     float temp;
//     float X,Y,Z, t1,t2;
//     Uint16 A,B,C,N,Sector;
//     float Ta, Tb, Tc;
//     float K=1.73205081;//sqrt(3)/2
//     //p->T=1.0;//Normalize the whole modulation period
//     X= K*p->Ubeta/p->Vdc*p->T;
//     Y=(K*p->Ubeta+3*p->Ualpha)/(2*p->Vdc)*p->T;
//     Z=(K*p->Ubeta-3*p->Ualpha)/(2*p->Vdc)*p->T;
//    //
//     if(p->Ubeta>0)
//       {A=1;}
//     else
//       {A=0;}
//
//     if( (K*p->Ualpha - p->Ubeta)>0 )
//       {B=1;}
//     else
//       {B=0;}
//
//     if((-K*p->Ualpha - p->Ubeta)>0)
//       {C=1;}
//     else
//       {C=0;}
//
//     N=A+2*B+4*C;
////
//     switch(N)
//     {
//        case 1:{Sector=2;break;}
//        case 2:{Sector=6;break;}
//        case 3:{Sector=1;break;}
//        case 4:{Sector=4;break;}
//        case 5:{Sector=3;break;}
//        case 6:{Sector=5;break;}
//         default:{;}
//     }
// //
//    switch(Sector)
//    {
//        case 1: {t1=-Z; t2= X;break;}
//        case 2: {t1= Z; t2= Y;break;}
//        case 3: {t1= X; t2=-Y;break;}
//        case 4: {t1=-X; t2= Z;break;}
//        case 5: {t1=-Y; t2=-Z;break;}
//        case 6: {t1= Y; t2=-X;break;}
//          default:{;}
//    }
//
//    if((t1+t2)>p->T)//�Թ�����������е���
//     {
//          temp=t1+t2;
//          t1=t1*p->T/temp;
//          t2=t2*p->T/temp;
//     }
//
//    //
//     Ta=(p->T-t1-t2)/4;//����ʱ�����
//     Tb=Ta+t1/2;
//     Tc=Tb+t2/2;
//
//     switch(Sector)
//      {
//        case 1: {p->Tcmpa=Ta; p->Tcmpb=Tb; p->Tcmpc=Tc; break;}
//        case 2: {p->Tcmpa=Tb; p->Tcmpb=Ta; p->Tcmpc=Tc; break;}
//        case 3: {p->Tcmpa=Tc; p->Tcmpb=Ta; p->Tcmpc=Tb; break;}
//        case 4: {p->Tcmpa=Tc; p->Tcmpb=Tb; p->Tcmpc=Ta; break;}
//        case 5: {p->Tcmpa=Tb; p->Tcmpb=Tc; p->Tcmpc=Ta; break;}
//        case 6: {p->Tcmpa=Ta; p->Tcmpb=Tc; p->Tcmpc=Tb; break;}
//          default:{;}
//      }
//}
//
void
InitEPwm1Example()
{
    //
    // Setup TBCLK
    //
    EPwm1Regs.TBPRD = PRD_L;      // Set timer period 801 TBCLKs
    EPwm1Regs.TBPHS.half.TBPHS = 0x0000;      // Phase is 0
    EPwm1Regs.TBCTR = 0x0000;                 // Clear counter

    //
    // Set Compare values
    //
    EPwm1Regs.CMPA.half.CMPA = 0;     // Set compare A value
    EPwm1Regs.CMPB = 0;               // Set Compare B value

    //
    // Setup counter mode
    //
    EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Count up
    EPwm1Regs.TBCTL.bit.PHSEN = TB_ENABLE;        // Disable phase loading
    EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;       // SYSCLKOUT
    EPwm1Regs.TBCTL.bit.CLKDIV = TB_DIV1;
    EPwm1Regs.TBCTL.bit.PHSDIR = 0x1;

    //
    // Setup shadowing
    //
    EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;  // Load on Zero
    EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

    //
    // Set actions
    //
    EPwm1Regs.AQCTLA.bit.CAU = AQ_TOGGLE;     //����ֵ=�Ƚ�ֵʱ���ȡ��  EPWMxA tgc
    EPwm1Regs.AQCTLA.bit.ZRO = AQ_CLEAR;   //����0ʱ�����
    EPwm1Regs.AQCTLA.bit.CAD = AQ_TOGGLE;
    EPwm1Regs.DBCTL.bit.POLSEL= 0x2;//EPWMxB��ת����
    EPwm1Regs.DBCTL.bit.OUT_MODE= 0x3;//A��Bͨ��ʹ����ʱ RED FEDĬ�϶���0����
    EPwm1Regs.DBRED=30;
    EPwm1Regs.DBFED=30;
//    EPwm1Regs.AQCTLB.bit.CBU = AQ_TOGGLE;    // ����ֵ=�Ƚ�ֵʱ���ȡ��
//    EPwm1Regs.AQCTLB.bit.ZRO = AQ_SET;  // ����0ʱ�����

    //
    // Interrupt where we will change the Compare Values
    //
    EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;      // Select INT on Zero event
    EPwm1Regs.ETSEL.bit.INTEN = 1;                 // Enable INT
    EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;            // ÿ���¼����ж�

    //
    // Information this example uses to keep track of the direction the
    // CMPA/CMPB values are moving, the min and max allowed values and
    // a pointer to the correct ePWM registers
    //
//    epwm1_info.EPwm_CMPA_Direction = EPWM_CMP_UP; // Start by increasing CMPA &
//    epwm1_info.EPwm_CMPB_Direction = EPWM_CMP_DOWN; // decreasing CMPB
//    epwm1_info.EPwmTimerIntCount = 0;      // Zero the interrupt counter
//    epwm1_info.EPwmRegHandle = &EPwm1Regs; //Set the pointer to the ePWM module
//    epwm1_info.EPwmMaxCMPA = EPWM1_MAX_CMPA;  // Setup min/max CMPA/CMPB values
//    epwm1_info.EPwmMinCMPA = EPWM1_MIN_CMPA;
//    epwm1_info.EPwmMaxCMPB = EPWM1_MAX_CMPB;
//    epwm1_info.EPwmMinCMPB = EPWM1_MIN_CMPB;
}

void
InitEPwm2Example()
{
    //
    // Setup TBCLK
    //
    EPwm2Regs.TBPRD = PRD_L;    // Set timer period 801 TBCLKs
    EPwm2Regs.TBPHS.half.TBPHS = 0x0000;    // Phase is 0
    EPwm2Regs.TBCTR = 0x0000;               // Clear counter

    //
    // Set Compare values
    //
    EPwm2Regs.CMPA.half.CMPA = 0;     // Set compare A value
    EPwm2Regs.CMPB = 0;               // Set Compare B value

    //
    // Setup counter mode
    //
    EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; // Count up
    EPwm2Regs.TBCTL.bit.PHSEN = TB_ENABLE;        // Disable phase loading
    EPwm2Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;       // SYSCLKOUT
    EPwm2Regs.TBCTL.bit.CLKDIV = TB_DIV1;

    //
    // Setup shadowing
    //
    EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm2Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;  // Load on Zero
    EPwm2Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

    //
    // Set actions
    //
    EPwm2Regs.AQCTLA.bit.CAU = AQ_TOGGLE;
    EPwm2Regs.AQCTLA.bit.ZRO = AQ_CLEAR;
    EPwm2Regs.AQCTLA.bit.CAD = AQ_CLEAR;
    EPwm2Regs.DBCTL.bit.POLSEL= 0x2;//EPWMxB��ת����
    EPwm2Regs.DBCTL.bit.OUT_MODE= 0x3;//A��Bͨ��ʹ����ʱ RED FEDĬ�϶���0����
    EPwm2Regs.DBRED=30;
    EPwm2Regs.DBFED=30;
//    EPwm2Regs.AQCTLB.bit.CBU = AQ_TOGGLE;
//    EPwm2Regs.AQCTLB.bit.ZRO = AQ_SET  ;

    //
    // Interrupt where we will change the Compare Values
    //
    EPwm2Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     // Select INT on Zero event
    EPwm2Regs.ETSEL.bit.INTEN = 1;                // Enable INT
    EPwm2Regs.ETPS.bit.INTPRD = ET_1ST;           // Generate INT on 3rd event

    //
    // Information this example uses to keep track of the direction the
    // CMPA/CMPB values are moving, the min and max allowed values and a
    // pointer to the correct ePWM registers
    //
//    epwm2_info.EPwm_CMPA_Direction = EPWM_CMP_UP; // Start by increasing CMPA &
//    epwm2_info.EPwm_CMPB_Direction = EPWM_CMP_UP; // increasing CMPB
//    epwm2_info.EPwmTimerIntCount = 0;      // Zero the interrupt counter
//    epwm2_info.EPwmRegHandle = &EPwm2Regs; //Set the pointer to the ePWM module
//    epwm2_info.EPwmMaxCMPA = EPWM2_MAX_CMPA;  // Setup min/max CMPA/CMPB values
//    epwm2_info.EPwmMinCMPA = EPWM2_MIN_CMPA;
//    epwm2_info.EPwmMaxCMPB = EPWM2_MAX_CMPB;
//    epwm2_info.EPwmMinCMPB = EPWM2_MIN_CMPB;
}

void 
InitEPwm3Example(void)
{
    //
    // Setup TBCLK
    //
    EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN;// Count up/down
    EPwm3Regs.TBPRD = PRD_L;          // Set timer period
    EPwm3Regs.TBCTL.bit.PHSEN = TB_ENABLE;       // Disable phase loading
    EPwm3Regs.TBPHS.half.TBPHS = 0x0000;          // Phase is 0
    EPwm3Regs.TBCTR = 0x0000;                     // Clear counter
    EPwm3Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;      // Clock ratio to SYSCLKOUT
    EPwm3Regs.TBCTL.bit.CLKDIV = TB_DIV1;

    //
    // Setup shadow register load on ZERO
    //
    EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO;
    EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO;

    //
    // Set Compare values
    //
    EPwm3Regs.CMPA.half.CMPA = 0;    // Set compare A value
    EPwm3Regs.CMPB = 0;              // Set Compare B value

    //
    // Set Actions
    //
    EPwm3Regs.AQCTLA.bit.CAU = AQ_TOGGLE;    // Set PWM3A on period
    EPwm3Regs.AQCTLA.bit.ZRO = AQ_CLEAR;  // Clear PWM3A on event B, down count
    EPwm3Regs.DBCTL.bit.POLSEL= 0x2;//EPWMxB��ת����
    EPwm3Regs.DBCTL.bit.OUT_MODE= 0x3;//A��Bͨ��ʹ����ʱ RED FEDĬ�϶���0����
    EPwm3Regs.AQCTLA.bit.CAD = AQ_CLEAR;
    EPwm3Regs.DBRED=30;
    EPwm3Regs.DBFED=30;
//    EPwm3Regs.AQCTLB.bit.CBU = AQ_TOGGLE;  // Clear PWM3A on period
//    EPwm3Regs.AQCTLB.bit.ZRO = AQ_SET;    // Set PWM3A on event A, up count

    //
    // Interrupt where we will change the Compare Values
    //
    EPwm3Regs.ETSEL.bit.INTSEL= ET_CTR_ZERO;     // Select INT on Zero event
    EPwm3Regs.ETSEL.bit.INTEN = 1;                // Enable INT
    EPwm3Regs.ETPS.bit.INTPRD = ET_1ST;           // Generate INT on 3rd event

    //
    // Information this example uses to keep track of the direction the 
    // CMPA/CMPB values are moving, the min and max allowed values and
    // a pointer to the correct ePWM registers
    //
//    epwm3_info.EPwm_CMPA_Direction = EPWM_CMP_UP; // Start by increasing CMPA &
//    epwm3_info.EPwm_CMPB_Direction = EPWM_CMP_DOWN; // decreasing CMPB
//    epwm3_info.EPwmTimerIntCount = 0;        // Zero the interrupt counter
//    epwm3_info.EPwmRegHandle = &EPwm3Regs; //Set the pointer to the ePWM module
//    epwm3_info.EPwmMaxCMPA = EPWM3_MAX_CMPA; // Setup min/max CMPA/CMPB values
//    epwm3_info.EPwmMinCMPA = EPWM3_MIN_CMPA;
//    epwm3_info.EPwmMaxCMPB = EPWM3_MAX_CMPB;
//    epwm3_info.EPwmMinCMPB = EPWM3_MIN_CMPB;
}

//
// update_compare -
//
//void
//update_compare(EPWM_INFO *epwm_info,)
//{
//    //
//    // Every 10'th interrupt, change the CMPA/CMPB values
//    //
//    if(epwm_info->EPwmTimerIntCount == 10)
//    {
//        epwm_info->EPwmTimerIntCount = 0;
//
//        //
//        // If we were increasing CMPA, check to see if we reached the max value
//        // If not, increase CMPA else, change directions and decrease CMPA
//        //
//        if(epwm_info->EPwm_CMPA_Direction == EPWM_CMP_UP)
//        {
//            if(epwm_info->EPwmRegHandle->CMPA.half.CMPA <
//               epwm_info->EPwmMaxCMPA)
//            {
//                epwm_info->EPwmRegHandle->CMPA.half.CMPA++;
//            }
//            else
//            {
//                epwm_info->EPwm_CMPA_Direction = EPWM_CMP_DOWN;
//                epwm_info->EPwmRegHandle->CMPA.half.CMPA--;
//            }
//        }
//
//        //
//        // If we were decreasing CMPA, check to see if we reached the min value
//        // If not, decrease CMPA else, change directions and increase CMPA
//        //
//        else
//        {
//            if(epwm_info->EPwmRegHandle->CMPA.half.CMPA ==
//               epwm_info->EPwmMinCMPA)
//            {
//                epwm_info->EPwm_CMPA_Direction = EPWM_CMP_UP;
//                epwm_info->EPwmRegHandle->CMPA.half.CMPA++;
//            }
//            else
//            {
//                epwm_info->EPwmRegHandle->CMPA.half.CMPA--;
//            }
//        }
//
//        //
//        // If we were increasing CMPB, check to see if we reached the max value
//        // If not, increase CMPB else, change directions and decrease CMPB
//        //
//        if(epwm_info->EPwm_CMPB_Direction == EPWM_CMP_UP)
//        {
//            if(epwm_info->EPwmRegHandle->CMPB < epwm_info->EPwmMaxCMPB)
//            {
//                epwm_info->EPwmRegHandle->CMPB++;
//            }
//            else
//            {
//                epwm_info->EPwm_CMPB_Direction = EPWM_CMP_DOWN;
//                epwm_info->EPwmRegHandle->CMPB--;
//            }
//        }
//
//        //
//        // If we were decreasing CMPB, check to see if we reached the min value
//        // If not, decrease CMPB else, change directions and increase CMPB
//        //
//        else
//        {
//            if(epwm_info->EPwmRegHandle->CMPB == epwm_info->EPwmMinCMPB)
//            {
//                epwm_info->EPwm_CMPB_Direction = EPWM_CMP_UP;
//                epwm_info->EPwmRegHandle->CMPB++;
//            }
//            else
//            {
//                epwm_info->EPwmRegHandle->CMPB--;
//            }
//        }
//    }
//
//    else
//    {
//        epwm_info->EPwmTimerIntCount++;
//    }
//
//    return;
//}

//
// End of File
//

